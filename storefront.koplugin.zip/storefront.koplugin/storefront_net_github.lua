local http = require("socket.http")
local json = require("json")
local url = require("socket.url")
local logger = require("logger")
local DataStorage = require("datastorage")
local LuaSettings = require("luasettings")

local ok_cfg, StorefrontConfig = pcall(require, "storefront_config")
if not ok_cfg then
    ok_cfg, StorefrontConfig = pcall(require, "storefront_configuration")
end
if not ok_cfg then
    StorefrontConfig = {}
end

local GitHubClient = {}

local BASE_URL = "https://api.github.com"
local USER_AGENT = "KOReader-Storefront"

-- Token entered through the Settings UI (see storefront_settings_card.lua),
-- stored separately from storefront_configuration.lua so users don't have to
-- hand-edit a Lua file just to add a PAT. Kept in its own settings file (not
-- StorefrontSettings in main.lua) so this module has no dependency on it.
local AUTH_SETTINGS_PATH = DataStorage:getSettingsDir() .. "/Storefront_github.lua"
local AuthSettings = LuaSettings:open(AUTH_SETTINGS_PATH)
local TOKEN_KEY = "github_token"
local CATALOG_MODE_KEY = "catalog_mode"

local function joinQueryParts(parts)
    if not parts or #parts == 0 then
        return ""
    end
    return table.concat(parts, " ")
end

local function newTableSink(target)
    return function(chunk, err)
        if chunk then
            target[#target + 1] = chunk
        end
        return 1, err
    end
end

-- Returns the configured PAT, preferring the one saved via the Settings UI
-- over the legacy storefront_configuration.lua file (kept for users who
-- already set that up).
function GitHubClient.getToken()
    local saved = AuthSettings:readSetting(TOKEN_KEY)
    if type(saved) == "string" and saved ~= "" then
        return saved
    end
    local auth = StorefrontConfig.auth and StorefrontConfig.auth.github
    local token = auth and auth.token
    if token and token ~= "" and token ~= "your_github_token" then
        return token
    end
    return nil
end

function GitHubClient.hasAuthToken()
    return GitHubClient.getToken() ~= nil
end

function GitHubClient.getCatalogMode()
    local saved = AuthSettings:readSetting(CATALOG_MODE_KEY)
    if saved == "direct" or saved == "static" then
        return saved
    end
    if GitHubClient.hasAuthToken() then
        return "direct"
    end
    return "static"
end

function GitHubClient.setCatalogMode(mode)
    if mode == "direct" or mode == "static" then
        AuthSettings:saveSetting(CATALOG_MODE_KEY, mode)
    else
        AuthSettings:delSetting(CATALOG_MODE_KEY)
    end
    AuthSettings:flush()
end

function GitHubClient.isDirectApiEnabled()
    return GitHubClient.getCatalogMode() == "direct"
end

-- Saves (or, when token is nil/empty, clears) the PAT entered via the
-- Settings UI.
function GitHubClient.setToken(token)
    token = token and token:gsub("^%s+", ""):gsub("%s+$", "") or ""
    if token == "" then
        AuthSettings:delSetting(TOKEN_KEY)
    else
        AuthSettings:saveSetting(TOKEN_KEY, token)
    end
    AuthSettings:flush()
end

local function getAuthHeaders()
    local token = GitHubClient.getToken()
    if not token then
        return nil
    end
    local scheme = (StorefrontConfig.auth and StorefrontConfig.auth.github and StorefrontConfig.auth.github.scheme) or "token"
    return {
        ["Authorization"] = string.format("%s %s", scheme, token),
    }
end

local function request(path, query)
    local response_body = {}
    local target = BASE_URL .. path
    if query and query ~= "" then
        target = target .. "?" .. query
    end
    logger.dbg("Storefront HTTP", target)
    local headers = {
        ["Accept"] = "application/vnd.github+json",
        ["User-Agent"] = USER_AGENT,
    }
    local auth_headers = getAuthHeaders()
    if auth_headers then
        for key, value in pairs(auth_headers) do
            headers[key] = value
        end
    end
    local _, code = http.request{
        url = target,
        headers = headers,
        sink = newTableSink(response_body),
    }
    local body = table.concat(response_body)
    return tonumber(code), body
end

local function buildQuery(opts)
    local query_parts = {}
    if opts.q and opts.q ~= "" then
        table.insert(query_parts, "q=" .. url.escape(opts.q))
    end
    if opts.sort and opts.sort ~= "" then
        table.insert(query_parts, "sort=" .. opts.sort)
    end
    if opts.order and opts.order ~= "" then
        table.insert(query_parts, "order=" .. opts.order)
    end
    table.insert(query_parts, "page=" .. tostring(opts.page or 1))
    table.insert(query_parts, "per_page=" .. tostring(opts.per_page or 30))
    return table.concat(query_parts, "&")
end

local function buildTopicQuery(topics, extra_terms)
    local parts = {}
    if topics then
        for _, topic in ipairs(topics) do
            if topic and topic ~= "" then
                table.insert(parts, string.format("topic:%s", topic))
            end
        end
    end
    if extra_terms and extra_terms ~= "" then
        table.insert(parts, extra_terms)
    end
    return joinQueryParts(parts)
end

function GitHubClient.searchRepositories(opts)
    opts = opts or {}
    local query = buildQuery(opts)
    local code, body = request("/search/repositories", query)
    if code ~= 200 then
        logger.warn("GitHub search error", code, body)
        -- GitHub's search endpoint rejects fine-grained PATs outright (they're
        -- not in its list of supported token types), returning a 403 with this
        -- wording rather than an actual rate-limit response. Classic tokens work.
        local is_fine_grained_unsupported = code == 403
            and body
            and body:lower():find("fine%-grained", 1, true) ~= nil
        local err_info = {
            code = code,
            body = body,
            is_rate_limit = (code == 403 or code == 429) and not is_fine_grained_unsupported,
            is_fine_grained_unsupported = is_fine_grained_unsupported,
        }
        return nil, err_info
    end
    local ok, parsed = pcall(json.decode, body)
    if not ok then
        logger.warn("GitHub search decode error", parsed)
        return nil, { code = 0, body = "decode", is_rate_limit = false }
    end
    return parsed, nil
end

function GitHubClient.hasAuthToken()
    return GitHubClient.getToken() ~= nil
end

function GitHubClient.searchByTopics(topics, opts)
    opts = opts or {}
    local q = buildTopicQuery(topics, opts.extra)
    opts.q = q
    opts.sort = opts.sort or "stars"
    opts.order = opts.order or "desc"
    opts.per_page = opts.per_page or 100
    return GitHubClient.searchRepositories(opts)
end

function GitHubClient.fetchRepoTree(owner, repo, ref)
    if not owner or not repo then
        return nil, "missing owner/repo"
    end
    ref = ref or "HEAD"
    local path = string.format("/repos/%s/%s/git/trees/%s", owner, repo, ref)
    local code, body = request(path, "recursive=1")
    if code ~= 200 then
        logger.warn("GitHub fetch tree error", owner .. "/" .. repo, ref, code, body)
        return nil, { code = code, body = body }
    end
    local ok, parsed = pcall(json.decode, body)
    if not ok then
        logger.warn("GitHub fetch tree decode error", parsed)
        return nil, "decode"
    end
    return parsed, nil
end

function GitHubClient.fetchRepoMetadata(owner, repo)
    if not owner or not repo then
        return nil, "missing owner/repo"
    end
    local path = string.format("/repos/%s/%s", owner, repo)
    local code, body = request(path)
    if code ~= 200 then
        logger.warn("GitHub fetch repo metadata error", owner .. "/" .. repo, code, body)
        return nil, { code = code, body = body }
    end
    local ok, parsed = pcall(json.decode, body)
    if not ok then
        logger.warn("GitHub fetch repo metadata decode error", parsed)
        return nil, "decode"
    end
    return parsed, nil
end

function GitHubClient.fetchLatestRelease(owner, repo)
    if not owner or not repo then
        return nil, "missing owner/repo"
    end
    local path = string.format("/repos/%s/%s/releases/latest", owner, repo)
    local code, body = request(path)
    if code ~= 200 then
        logger.warn("GitHub fetch latest release error", owner .. "/" .. repo, code, body)
        return nil, { code = code, body = body }
    end
    local ok, parsed = pcall(json.decode, body)
    if not ok then
        logger.warn("GitHub fetch latest release decode error", parsed)
        return nil, "decode"
    end
    return parsed, nil
end

-- Fetch all releases of a repository (sorted from newest to oldest by GitHub).
-- Pagination is performed transparently up to `max_pages` to avoid hammering
-- the API for repositories with hundreds of releases.
function GitHubClient.fetchReleases(owner, repo, opts)
    if not owner or not repo then
        return nil, "missing owner/repo"
    end
    opts = opts or {}
    local per_page = tonumber(opts.per_page) or 100
    local max_pages = tonumber(opts.max_pages) or 5
    local results = {}
    for page = 1, max_pages do
        local path = string.format("/repos/%s/%s/releases", owner, repo)
        local query = string.format("per_page=%d&page=%d", per_page, page)
        local code, body = request(path, query)
        if code ~= 200 then
            logger.warn("GitHub fetch releases error", owner .. "/" .. repo, code, body)
            if #results > 0 then
                return results, nil
            end
            return nil, { code = code, body = body }
        end
        local ok, parsed = pcall(json.decode, body)
        if not ok or type(parsed) ~= "table" then
            logger.warn("GitHub fetch releases decode error", parsed)
            if #results > 0 then
                return results, nil
            end
            return nil, "decode"
        end
        if #parsed == 0 then
            break
        end
        for _, rel in ipairs(parsed) do
            table.insert(results, rel)
        end
        if #parsed < per_page then
            break
        end
    end
    return results, nil
end

-- Fetch the list of commits between two refs (tags, branches, SHAs).
-- Uses the GitHub compare endpoint: /repos/{owner}/{repo}/compare/{base}...{head}
-- Returns the parsed JSON table (contains `commits`, `total_commits`, etc.) or nil + err.
function GitHubClient.fetchCompareCommits(owner, repo, base, head)
    if not owner or not repo or not base or not head then
        return nil, "missing parameters"
    end
    local path = string.format("/repos/%s/%s/compare/%s...%s", owner, repo, base, head)
    local code, body = request(path)
    if code ~= 200 then
        logger.warn("GitHub compare error", owner .. "/" .. repo, base .. "..." .. head, code, body)
        return nil, { code = code, body = body }
    end
    local ok, parsed = pcall(json.decode, body)
    if not ok then
        logger.warn("GitHub compare decode error", parsed)
        return nil, "decode"
    end
    return parsed, nil
end

local function markdownToHtml(md, owner, repo)
    if type(md) ~= "string" or md == "" or md == json.null then
        return "<div class=\"markdown-body\"><p>No release notes or README content provided.</p></div>"
    end

    -- Clean control characters and null bytes
    md = md:gsub("[%z\1-\8\11\12\14-\31]", "")

    -- Enforce max body length (50 KB) to avoid MuPDF memory exhaustion
    if #md > 50000 then
        md = md:sub(1, 50000) .. "\n\n*(Release notes truncated...)*"
    end

    -- Strip HTML comments
    md = md:gsub("<!%-%-.-%-%->", "")

    -- Convert unrecognized named HTML entities to UTF-8 characters
    local entity_map = {
        ["&nbsp;"] = " ",
        ["&mdash;"] = "—",
        ["&ndash;"] = "–",
        ["&hellip;"] = "…",
        ["&rsquo;"] = "’",
        ["&lsquo;"] = "‘",
        ["&rdquo;"] = "”",
        ["&ldquo;"] = "“",
        ["&bull;"] = "•",
        ["&copy;"] = "©",
        ["&trade;"] = "™",
        ["&check;"] = "✓",
    }
    for entity, repl in pairs(entity_map) do
        md = md:gsub(entity, repl)
    end

    local lines = {}
    local in_code_block = false
    local in_list = false

    for line in (md .. "\n"):gmatch("(.-)\r?\n") do
        if line:match("^%s*```") then
            if in_code_block then
                table.insert(lines, "</code></pre>")
                in_code_block = false
            else
                if in_list then table.insert(lines, "</ul>"); in_list = false end
                table.insert(lines, "<pre><code>")
                in_code_block = true
            end
        elseif in_code_block then
            local escaped = line:gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;")
            table.insert(lines, escaped)
        else
            local processed = line:gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;")

            -- Convert Markdown Images: ![alt](url) -> <img src="url" alt="alt"/>
            processed = processed:gsub("!%[([^%]]*)%]%(([^%)]+)%)", function(alt, src)
                if owner and repo and type(owner) == "string" and type(repo) == "string" and not src:find("^https?://") and not src:find("^data:") then
                    local clean_src = src:gsub("^%./", "")
                    src = string.format("https://raw.githubusercontent.com/%s/%s/HEAD/%s", owner, repo, clean_src)
                end
                return string.format('<img src="%s" alt="%s"/>', src, alt)
            end)

            -- Restore/convert raw HTML img tags that got escaped by &lt;img ... &gt;
            processed = processed:gsub("&lt;img%s+(.-)/?&gt;", function(attrs)
                local unescaped_attrs = attrs:gsub("&quot;", '"'):gsub("&amp;", "&")
                if owner and repo and type(owner) == "string" and type(repo) == "string" then
                    unescaped_attrs = unescaped_attrs:gsub('src=["\']([^"\']+)["\']', function(src)
                        if not src:find("^https?://") and not src:find("^data:") then
                            local clean_src = src:gsub("^%./", "")
                            src = string.format("https://raw.githubusercontent.com/%s/%s/HEAD/%s", owner, repo, clean_src)
                        end
                        return string.format('src="%s"', src)
                    end)
                end
                return string.format('<img %s/>', unescaped_attrs)
            end)

            -- Convert/clean problematic raw HTML tags (e.g. details/summary/table)
            processed = processed:gsub("&lt;details&gt;", "<div>")
            processed = processed:gsub("&lt;/details&gt;", "</div>")
            processed = processed:gsub("&lt;summary&gt;", "<p><b>")
            processed = processed:gsub("&lt;/summary&gt;", "</b></p>")
            processed = processed:gsub("&lt;br%s*/?&gt;", "<br/>")

            -- Inline formatting (using replacement functions to avoid Lua gsub '%' capture expansion crashes)
            processed = processed:gsub("%[([^%]]+)%]%(([^%)]+)%)", function(label, url)
                return string.format('<a href="%s">%s</a>', url, label)
            end)
            processed = processed:gsub("%*%*([^*]+)%*%*", function(b) return string.format("<b>%s</b>", b) end)
            processed = processed:gsub("__([^_]+)__", function(b) return string.format("<b>%s</b>", b) end)
            processed = processed:gsub("%*([^*]+)%*", function(i) return string.format("<i>%s</i>", i) end)
            processed = processed:gsub("_([^_]+)_", function(i) return string.format("<i>%s</i>", i) end)
            processed = processed:gsub("`([^`]+)`", function(c) return string.format("<code>%s</code>", c) end)

            -- Headings
            local h6 = processed:match("^######%s+(.+)")
            local h5 = processed:match("^#####%s+(.+)")
            local h4 = processed:match("^####%s+(.+)")
            local h3 = processed:match("^###%s+(.+)")
            local h2 = processed:match("^##%s+(.+)")
            local h1 = processed:match("^#%s+(.+)")

            if h1 then
                if in_list then table.insert(lines, "</ul>"); in_list = false end
                table.insert(lines, "<h1>" .. h1 .. "</h1>")
            elseif h2 then
                if in_list then table.insert(lines, "</ul>"); in_list = false end
                table.insert(lines, "<h2>" .. h2 .. "</h2>")
            elseif h3 then
                if in_list then table.insert(lines, "</ul>"); in_list = false end
                table.insert(lines, "<h3>" .. h3 .. "</h3>")
            elseif h4 then
                if in_list then table.insert(lines, "</ul>"); in_list = false end
                table.insert(lines, "<h4>" .. h4 .. "</h4>")
            elseif h5 then
                if in_list then table.insert(lines, "</ul>"); in_list = false end
                table.insert(lines, "<h5>" .. h5 .. "</h5>")
            elseif h6 then
                if in_list then table.insert(lines, "</ul>"); in_list = false end
                table.insert(lines, "<h6>" .. h6 .. "</h6>")
            else
                local item = processed:match("^%s*[%-%*]%s+(.+)")
                if item then
                    if not in_list then
                        table.insert(lines, "<ul>")
                        in_list = true
                    end
                    table.insert(lines, "<li>" .. item .. "</li>")
                else
                    if in_list then
                        table.insert(lines, "</ul>")
                        in_list = false
                    end
                    if processed:match("^%s*$") then
                        table.insert(lines, "<br/>")
                    else
                        table.insert(lines, "<p>" .. processed .. "</p>")
                    end
                end
            end
        end
    end

    if in_code_block then table.insert(lines, "</code></pre>") end
    if in_list then table.insert(lines, "</ul>") end

    return '<div class="markdown-body">\n' .. table.concat(lines, "\n") .. '\n</div>'
end

GitHubClient.markdownToHtml = markdownToHtml

-- Fetch the HTML representation of README.
-- Returns raw HTML string, or nil + error.
function GitHubClient.fetchReadmeHtml(owner, repo)
    if not owner or not repo then
        return nil, "missing parameters"
    end

    -- First try direct API if enabled or available
    local path = string.format("/repos/%s/%s/readme", owner, repo)
    local response_body = {}
    local target = BASE_URL .. path
    logger.dbg("Storefront HTTP readme html", target)
    local headers = {
        ["Accept"] = "application/vnd.github.html",
        ["User-Agent"] = USER_AGENT,
    }
    local auth_headers = getAuthHeaders()
    if auth_headers then
        for key, value in pairs(auth_headers) do
            headers[key] = value
        end
    end
    local _, code = http.request{
        url = target,
        headers = headers,
        sink = newTableSink(response_body),
    }
    local body = table.concat(response_body)
    if tonumber(code) == 200 and body ~= "" then
        body = body:gsub('src=["\']([^"\']+)["\']', function(src)
            if not src:find("^https?://") and not src:find("^data:") and owner and repo then
                local clean_src = src:gsub("^%./", "")
                if clean_src:find("^blob/") or clean_src:find("^raw/") then
                    return string.format('src="https://raw.githubusercontent.com/%s/%s/%s"', owner, repo, clean_src:gsub("^blob/", ""):gsub("^raw/", ""))
                else
                    return string.format('src="https://raw.githubusercontent.com/%s/%s/HEAD/%s"', owner, repo, clean_src)
                end
            end
            return string.format('src="%s"', src)
        end)
        return body, nil
    end

    -- Fallback for Storefront mode / API rate limits: fetch raw README from GitHub CDN
    local raw_url = string.format("https://raw.githubusercontent.com/%s/%s/HEAD/README.md", owner, repo)
    local raw_response = {}
    local _, raw_code = http.request{
        url = raw_url,
        headers = {
            ["User-Agent"] = USER_AGENT,
        },
        sink = newTableSink(raw_response),
    }
    local raw_body = table.concat(raw_response)
    if tonumber(raw_code) == 200 and raw_body ~= "" then
        return markdownToHtml(raw_body, owner, repo), nil
    end

    return nil, string.format("HTTP %s", tostring(code))
end

return GitHubClient
